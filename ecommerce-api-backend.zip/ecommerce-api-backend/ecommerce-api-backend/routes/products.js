const express = require('express');
const { ObjectId } = require('mongodb');
const { body, validationResult, param } = require('express-validator');

const router = express.Router();

// Error handling middleware
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ 
      error: 'Validation failed', 
      details: errors.array() 
    });
  }
  next();
};

// Get asyncHandler from app locals
const getAsyncHandler = (req) => req.app.locals.asyncHandler;

// Get all products with pagination and filtering
router.get('/', (req, res, next) => {
  const asyncHandler = getAsyncHandler(req);
  asyncHandler(async (req, res) => {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;
    
    const filter = {};
    if (req.query.category) filter.category = req.query.category;
    if (req.query.brand) filter.brand = req.query.brand;
    if (req.query.colour) filter.colour = req.query.colour;
    if (req.query.minPrice) filter.price = { $gte: parseFloat(req.query.minPrice) };
    if (req.query.maxPrice) {
      filter.price = { ...filter.price, $lte: parseFloat(req.query.maxPrice) };
    }
    if (req.query.inStock === 'true') filter.stock = { $gt: 0 };
    if (req.query.inStock === 'false') filter.stock = { $eq: 0 };
    
    const products = await req.db.collection('products')
      .find(filter)
      .skip(skip)
      .limit(limit)
      .toArray();
      
    const total = await req.db.collection('products').countDocuments(filter);
    
    res.json({
      products,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    });
  })(req, res, next);
});

// Get single product by MongoDB ObjectId
router.get('/:id', [
  param('id').isMongoId().withMessage('Invalid product ID')
], handleValidationErrors, (req, res, next) => {
  const asyncHandler = getAsyncHandler(req);
  asyncHandler(async (req, res) => {
    const product = await req.db.collection('products').findOne({ 
      _id: new ObjectId(req.params.id) 
    });
    
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }
    
    res.json(product);
  })(req, res, next);
});

// Get single product by custom ID
router.get('/id/:productId', [
  param('productId').notEmpty().withMessage('Product ID is required')
], handleValidationErrors, (req, res, next) => {
  const asyncHandler = getAsyncHandler(req);
  asyncHandler(async (req, res) => {
    const product = await req.db.collection('products').findOne({ 
      id: req.params.productId 
    });
    
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }
    
    res.json(product);
  })(req, res, next);
});

// Get products by category
router.get('/category/:category', [
  param('category').notEmpty().withMessage('Category is required')
], (req, res, next) => {
  const asyncHandler = getAsyncHandler(req);
  asyncHandler(async (req, res) => {
    const products = await req.db.collection('products').find({ 
      category: req.params.category 
    }).toArray();
    
    res.json(products);
  })(req, res, next);
});

// Get products by brand
router.get('/brand/:brand', [
  param('brand').notEmpty().withMessage('Brand is required')
], (req, res, next) => {
  const asyncHandler = getAsyncHandler(req);
  asyncHandler(async (req, res) => {
    const products = await req.db.collection('products').find({ 
      brand: req.params.brand 
    }).toArray();
    
    res.json(products);
  })(req, res, next);
});

// Search products by name
router.get('/search/:query', [
  param('query').notEmpty().withMessage('Search query is required')
], (req, res, next) => {
  const asyncHandler = getAsyncHandler(req);
  asyncHandler(async (req, res) => {
    const searchQuery = req.params.query;
    const products = await req.db.collection('products').find({
      name: { $regex: searchQuery, $options: 'i' }
    }).toArray();
    
    res.json(products);
  })(req, res, next);
});

// Create product
router.post('/', [
  body('name').notEmpty().withMessage('Name is required'),
  body('price').isNumeric().withMessage('Price must be a number'),
  body('category').notEmpty().withMessage('Category is required'),
  body('stock').isInt({ min: 0 }).withMessage('Stock must be a non-negative integer'),
  body('brand').notEmpty().withMessage('Brand is required'),
  body('colour').notEmpty().withMessage('Colour is required')
], handleValidationErrors, (req, res, next) => {
  const asyncHandler = getAsyncHandler(req);
  asyncHandler(async (req, res) => {
    // Generate product ID
    const productCount = await req.db.collection('products').countDocuments();
    const productId = `prod_${String(productCount + 1).padStart(3, '0')}`;
    
    const productData = {
      id: productId,
      name: req.body.name,
      price: req.body.price,
      category: req.body.category,
      stock: req.body.stock,
      brand: req.body.brand,
      colour: req.body.colour
    };
    
    const result = await req.db.collection('products').insertOne(productData);
    res.status(201).json({ 
      message: 'Product created successfully',
      productId: result.insertedId,
      product: productData
    });
  })(req, res, next);
});

// Update product by MongoDB ObjectId
router.put('/:id', [
  param('id').isMongoId().withMessage('Invalid product ID'),
  body('name').optional().notEmpty().withMessage('Name cannot be empty'),
  body('price').optional().isNumeric().withMessage('Price must be a number'),
  body('stock').optional().isInt({ min: 0 }).withMessage('Stock must be a non-negative integer'),
  body('category').optional().notEmpty().withMessage('Category cannot be empty'),
  body('brand').optional().notEmpty().withMessage('Brand cannot be empty'),
  body('colour').optional().notEmpty().withMessage('Colour cannot be empty')
], handleValidationErrors, (req, res, next) => {
  const asyncHandler = getAsyncHandler(req);
  asyncHandler(async (req, res) => {
    const updateData = req.body;
    
    const result = await req.db.collection('products').updateOne(
      { _id: new ObjectId(req.params.id) },
      { $set: updateData }
    );
    
    if (result.matchedCount === 0) {
      return res.status(404).json({ error: 'Product not found' });
    }
    
    res.json({ message: 'Product updated successfully' });
  })(req, res, next);
});

// Update product by custom ID
router.put('/id/:productId', [
  param('productId').notEmpty().withMessage('Product ID is required'),
  body('name').optional().notEmpty().withMessage('Name cannot be empty'),
  body('price').optional().isNumeric().withMessage('Price must be a number'),
  body('stock').optional().isInt({ min: 0 }).withMessage('Stock must be a non-negative integer'),
  body('category').optional().notEmpty().withMessage('Category cannot be empty'),
  body('brand').optional().notEmpty().withMessage('Brand cannot be empty'),
  body('colour').optional().notEmpty().withMessage('Colour cannot be empty')
], handleValidationErrors, (req, res, next) => {
  const asyncHandler = getAsyncHandler(req);
  asyncHandler(async (req, res) => {
    const updateData = req.body;
    
    const result = await req.db.collection('products').updateOne(
      { id: req.params.productId },
      { $set: updateData }
    );
    
    if (result.matchedCount === 0) {
      return res.status(404).json({ error: 'Product not found' });
    }
    
    res.json({ message: 'Product updated successfully' });
  })(req, res, next);
});

// Update product stock by MongoDB ObjectId
router.patch('/:id/stock', [
  param('id').isMongoId().withMessage('Invalid product ID'),
  body('stock').isInt({ min: 0 }).withMessage('Stock must be a non-negative integer')
], handleValidationErrors, (req, res, next) => {
  const asyncHandler = getAsyncHandler(req);
  asyncHandler(async (req, res) => {
    const result = await req.db.collection('products').updateOne(
      { _id: new ObjectId(req.params.id) },
      { $set: { stock: req.body.stock } }
    );
    
    if (result.matchedCount === 0) {
      return res.status(404).json({ error: 'Product not found' });
    }
    
    res.json({ message: 'Product stock updated successfully' });
  })(req, res, next);
});

// Update product stock by custom ID
router.patch('/id/:productId/stock', [
  param('productId').notEmpty().withMessage('Product ID is required'),
  body('stock').isInt({ min: 0 }).withMessage('Stock must be a non-negative integer')
], handleValidationErrors, (req, res, next) => {
  const asyncHandler = getAsyncHandler(req);
  asyncHandler(async (req, res) => {
    const result = await req.db.collection('products').updateOne(
      { id: req.params.productId },
      { $set: { stock: req.body.stock } }
    );
    
    if (result.matchedCount === 0) {
      return res.status(404).json({ error: 'Product not found' });
    }
    
    res.json({ message: 'Product stock updated successfully' });
  })(req, res, next);
});

// Delete product by MongoDB ObjectId
router.delete('/:id', [
  param('id').isMongoId().withMessage('Invalid product ID')
], handleValidationErrors, (req, res, next) => {
  const asyncHandler = getAsyncHandler(req);
  asyncHandler(async (req, res) => {
    const result = await req.db.collection('products').deleteOne({ 
      _id: new ObjectId(req.params.id) 
    });
    
    if (result.deletedCount === 0) {
      return res.status(404).json({ error: 'Product not found' });
    }
    
    res.json({ message: 'Product deleted successfully' });
  })(req, res, next);
});

// Delete product by custom ID
router.delete('/id/:productId', [
  param('productId').notEmpty().withMessage('Product ID is required')
], handleValidationErrors, (req, res, next) => {
  const asyncHandler = getAsyncHandler(req);
  asyncHandler(async (req, res) => {
    const result = await req.db.collection('products').deleteOne({ 
      id: req.params.productId 
    });
    
    if (result.deletedCount === 0) {
      return res.status(404).json({ error: 'Product not found' });
    }
    
    res.json({ message: 'Product deleted successfully' });
  })(req, res, next);
});

// Get all categories
router.get('/meta/categories', (req, res, next) => {
  const asyncHandler = getAsyncHandler(req);
  asyncHandler(async (req, res) => {
    const categories = await req.db.collection('products').distinct('category');
    res.json(categories);
  })(req, res, next);
});

// Get all brands
router.get('/meta/brands', (req, res, next) => {
  const asyncHandler = getAsyncHandler(req);
  asyncHandler(async (req, res) => {
    const brands = await req.db.collection('products').distinct('brand');
    res.json(brands);
  })(req, res, next);
});

// Get all colours
router.get('/meta/colours', (req, res, next) => {
  const asyncHandler = getAsyncHandler(req);
  asyncHandler(async (req, res) => {
    const colours = await req.db.collection('products').distinct('colour');
    res.json(colours);
  })(req, res, next);
});

module.exports = router;