const express = require('express');
const { ObjectId } = require('mongodb');
const { body, validationResult, param } = require('express-validator');

const router = express.Router();

// Middleware to check database connection
const checkDB = (req, res, next) => {
  if (!req.db) {
    return res.status(503).json({ error: 'Database connection not available' });
  }
  next();
};

// Error handling middleware
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ 
      error: 'Validation failed', 
      details: errors.array() 
    });
  }
  next();
};

// Async error handler
const asyncHandler = (fn) => (req, res, next) => {
  Promise.resolve(fn(req, res, next)).catch(next);
};

// Create Payment
router.post('/', [
  body('order_id').notEmpty().withMessage('Order ID is required'),
  body('user_id').notEmpty().withMessage('User ID is required'),
  body('amount').isNumeric().withMessage('Amount must be a number'),
  body('currency').notEmpty().withMessage('Currency is required'),
  body('payment_method').notEmpty().withMessage('Payment method is required'),
  body('payment_status').notEmpty().withMessage('Payment status is required'),
  body('transaction_id').notEmpty().withMessage('Transaction ID is required'),
  body('timestamp').isISO8601().toDate().withMessage('Timestamp must be a valid ISO date')
], checkDB, handleValidationErrors, asyncHandler(async (req, res) => {
  const paymentData = {
    ...req.body,
    createdAt: new Date(),
    updatedAt: new Date()
  };

  const result = await req.db.collection('payments').insertOne(paymentData);
  res.status(201).json({ 
    message: 'Payment record created successfully',
    paymentId: result.insertedId 
  });
}));

// Get all payments
router.get('/', checkDB, asyncHandler(async (req, res) => {
  const payments = await req.db.collection('payments').find({}).toArray();
  res.json(payments);
}));

// Update Payment
router.put('/:id', [
  param('id').isMongoId().withMessage('Invalid payment ID'),
  body('amount').optional().isNumeric().withMessage('Amount must be a number'),
  body('payment_status').optional().notEmpty().withMessage('Payment status cannot be empty'),
  body('payment_method').optional().notEmpty().withMessage('Payment method cannot be empty'),
  body('timestamp').optional().isISO8601().toDate().withMessage('Timestamp must be a valid ISO date')
], checkDB, handleValidationErrors, asyncHandler(async (req, res) => {
  const updateData = {
    ...req.body,
    updatedAt: new Date()
  };

  const result = await req.db.collection('payments').updateOne(
    { _id: new ObjectId(req.params.id) },
    { $set: updateData }
  );

  if (result.matchedCount === 0) {
    return res.status(404).json({ error: 'Payment record not found' });
  }

  res.json({ message: 'Payment record updated successfully' });
}));

// Delete Payment
router.delete('/:id', [
  param('id').isMongoId().withMessage('Invalid payment ID')
], checkDB, handleValidationErrors, asyncHandler(async (req, res) => {
  const result = await req.db.collection('payments').deleteOne({ 
    _id: new ObjectId(req.params.id) 
  });

  if (result.deletedCount === 0) {
    return res.status(404).json({ error: 'Payment record not found' });
  }

  res.json({ message: 'Payment record deleted successfully' });
}));

module.exports = router;