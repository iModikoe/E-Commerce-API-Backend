const express = require('express');
const { ObjectId } = require('mongodb');
const { body, validationResult, param } = require('express-validator');

const router = express.Router();

// Middleware to check database connection
const checkDB = (req, res, next) => {
  if (!req.db) {
    return res.status(503).json({ error: 'Database connection not available' });
  }
  next();
};

// Error handling middleware
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ 
      error: 'Validation failed', 
      details: errors.array() 
    });
  }
  next();
};

// Async error handler
const asyncHandler = (fn) => (req, res, next) => {
  Promise.resolve(fn(req, res, next)).catch(next);
};

// Create discount
router.post('/', [
  body('name').notEmpty().withMessage('Name is required'),
  body('description').notEmpty().withMessage('Description is required'),
  body('discount_type').isIn(['percentage', 'fixed']).withMessage('Discount type must be either percentage or fixed'),
  body('value').isNumeric().withMessage('Value must be a number'),
  body('code').notEmpty().withMessage('Code is required'),
  body('start_date').isISO8601().withMessage('Start date must be a valid ISO date'),
  body('end_date').isISO8601().withMessage('End date must be a valid ISO date'),
  body('min_order_amount').optional().isNumeric().withMessage('Minimum order amount must be a number'),
  body('max_uses').optional().isInt({ min: 0 }).withMessage('Max uses must be a non-negative integer'),
  body('uses_per_user').optional().isInt({ min: 0 }).withMessage('Uses per user must be a non-negative integer'),
  body('is_active').optional().isBoolean().withMessage('Is active must be a boolean')
], checkDB, handleValidationErrors, asyncHandler(async (req, res) => {
  // Check if discount code already exists
  const existingDiscount = await req.db.collection('discounts').findOne({ code: req.body.code });
  if (existingDiscount) {
    return res.status(400).json({ error: 'Discount code already exists' });
  }

  // Validate date range
  const startDate = new Date(req.body.start_date);
  const endDate = new Date(req.body.end_date);
  if (startDate >= endDate) {
    return res.status(400).json({ error: 'End date must be after start date' });
  }

  const discountData = {
    ...req.body,
    start_date: startDate,
    end_date: endDate,
    min_order_amount: req.body.min_order_amount || 0,
    max_uses: req.body.max_uses || 500,
    uses_per_user: req.body.uses_per_user || 1,
    is_active: req.body.is_active !== undefined ? req.body.is_active : true,
    created_at: new Date(),
    updated_at: new Date()
  };

  const result = await req.db.collection('discounts').insertOne(discountData);
  res.status(201).json({
    message: 'Discount created successfully',
    discountId: result.insertedId
  });
}));

// Get all discounts
router.get('/', checkDB, asyncHandler(async (req, res) => {
  const discounts = await req.db.collection('discounts').find({}).toArray();
  res.json(discounts);
}));

// Get discount by ID
router.get('/:id', [
  param('id').isMongoId().withMessage('Invalid discount ID')
], checkDB, handleValidationErrors, asyncHandler(async (req, res) => {
  const discount = await req.db.collection('discounts').findOne({
    _id: new ObjectId(req.params.id)
  });
  
  if (!discount) {
    return res.status(404).json({ error: 'Discount not found' });
  }
  
  res.json(discount);
}));

// Get discount by code
router.get('/code/:code', [
  param('code').notEmpty().withMessage('Discount code is required')
], checkDB, handleValidationErrors, asyncHandler(async (req, res) => {
  const discount = await req.db.collection('discounts').findOne({
    code: req.params.code.toUpperCase()
  });
  
  if (!discount) {
    return res.status(404).json({ error: 'Discount not found' });
  }
  
  // Check if discount is active and within date range
  const now = new Date();
  const isValid = discount.is_active && 
                  now >= discount.start_date && 
                  now <= discount.end_date;
  
  res.json({
    ...discount,
    isValid
  });
}));

// Update discount
router.put('/:id', [
  param('id').isMongoId().withMessage('Invalid discount ID'),
  body('name').optional().notEmpty().withMessage('Name cannot be empty'),
  body('description').optional().notEmpty().withMessage('Description cannot be empty'),
  body('discount_type').optional().isIn(['percentage', 'fixed']).withMessage('Discount type must be either percentage or fixed'),
  body('value').optional().isNumeric().withMessage('Value must be a number'),
  body('code').optional().notEmpty().withMessage('Code cannot be empty'),
  body('start_date').optional().isISO8601().withMessage('Start date must be a valid ISO date'),
  body('end_date').optional().isISO8601().withMessage('End date must be a valid ISO date'),
  body('min_order_amount').optional().isNumeric().withMessage('Minimum order amount must be a number'),
  body('max_uses').optional().isInt({ min: 0 }).withMessage('Max uses must be a non-negative integer'),
  body('uses_per_user').optional().isInt({ min: 0 }).withMessage('Uses per user must be a non-negative integer'),
  body('is_active').optional().isBoolean().withMessage('Is active must be a boolean')
], checkDB, handleValidationErrors, asyncHandler(async (req, res) => {
  // If updating code, check if it already exists for another discount
  if (req.body.code) {
    const existingDiscount = await req.db.collection('discounts').findOne({
      code: req.body.code,
      _id: { $ne: new ObjectId(req.params.id) }
    });
    if (existingDiscount) {
      return res.status(400).json({ error: 'Discount code already exists' });
    }
  }

  const updateData = { ...req.body, updated_at: new Date() };

  // Convert dates if provided
  if (req.body.start_date) {
    updateData.start_date = new Date(req.body.start_date);
  }
  if (req.body.end_date) {
    updateData.end_date = new Date(req.body.end_date);
  }

  // Validate date range if both dates are being updated
  if (updateData.start_date && updateData.end_date) {
    if (updateData.start_date >= updateData.end_date) {
      return res.status(400).json({ error: 'End date must be after start date' });
    }
  }

  const result = await req.db.collection('discounts').updateOne(
    { _id: new ObjectId(req.params.id) },
    { $set: updateData }
  );

  if (result.matchedCount === 0) {
    return res.status(404).json({ error: 'Discount not found' });
  }

  res.json({ message: 'Discount updated successfully' });
}));

// Delete discount
router.delete('/:id', [
  param('id').isMongoId().withMessage('Invalid discount ID')
], checkDB, handleValidationErrors, asyncHandler(async (req, res) => {
  const result = await req.db.collection('discounts').deleteOne({
    _id: new ObjectId(req.params.id)
  });

  if (result.deletedCount === 0) {
    return res.status(404).json({ error: 'Discount not found' });
  }

  res.json({ message: 'Discount deleted successfully' });
}));

// Activate/Deactivate discount
router.patch('/:id/toggle', [
  param('id').isMongoId().withMessage('Invalid discount ID')
], checkDB, handleValidationErrors, asyncHandler(async (req, res) => {
  const discount = await req.db.collection('discounts').findOne({
    _id: new ObjectId(req.params.id)
  });

  if (!discount) {
    return res.status(404).json({ error: 'Discount not found' });
  }

  const result = await req.db.collection('discounts').updateOne(
    { _id: new ObjectId(req.params.id) },
    { 
      $set: { 
        is_active: !discount.is_active,
        updated_at: new Date()
      }
    }
  );

  res.json({ 
    message: `Discount ${!discount.is_active ? 'activated' : 'deactivated'} successfully`,
    is_active: !discount.is_active
  });
}));

module.exports = router;