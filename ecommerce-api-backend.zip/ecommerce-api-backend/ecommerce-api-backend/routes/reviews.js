const express = require('express');
const { ObjectId } = require('mongodb');
const { body, validationResult, param } = require('express-validator');

const router = express.Router();

// Middleware for validation errors
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ 
      error: 'Validation failed', 
      details: errors.array() 
    });
  }
  next();
};

// Async error handler
const asyncHandler = (fn) => (req, res, next) => {
  Promise.resolve(fn(req, res, next)).catch(next);
};

// Create review
router.post('/', [
  body('user_id').notEmpty().withMessage('User ID is required'),
  body('product_id').notEmpty().withMessage('Product ID is required'),
  body('rating').isInt({ min: 1, max: 5 }).withMessage('Rating must be between 1 and 5'),
  body('comment').notEmpty().withMessage('Comment is required')
], handleValidationErrors, asyncHandler(async (req, res) => {
  const db = req.db;
  
  // Verify user and product exist
  const [user, product] = await Promise.all([
    db.collection('users').findOne({ id: req.body.user_id }),
    db.collection('products').findOne({ id: req.body.product_id })
  ]);
  
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  
  if (!product) {
    return res.status(404).json({ error: 'Product not found' });
  }
  
  // Check if user already reviewed this product
  const existingReview = await db.collection('reviews').findOne({
    user_id: req.body.user_id,
    product_id: req.body.product_id
  });
  
  if (existingReview) {
    return res.status(409).json({ error: 'User has already reviewed this product' });
  }
  
  // Generate review ID
  const reviewCount = await db.collection('reviews').countDocuments();
  const reviewId = `review_${String(reviewCount + 1).padStart(3, '0')}`;
  
  const reviewData = {
    id: reviewId,
    product_id: req.body.product_id,
    user_id: req.body.user_id,
    rating: req.body.rating,
    comment: req.body.comment,
    date: new Date()
  };
  
  const result = await db.collection('reviews').insertOne(reviewData);
  res.status(201).json({ 
    message: 'Review created successfully',
    reviewId: result.insertedId,
    review: reviewData
  });
}));

// Get reviews
router.get('/', asyncHandler(async (req, res) => {
  const db = req.db;
  const filter = {};
  if (req.query.product_id) filter.product_id = req.query.product_id;
  if (req.query.user_id) filter.user_id = req.query.user_id;
  if (req.query.rating) filter.rating = parseInt(req.query.rating);
  
  const reviews = await db.collection('reviews').find(filter).toArray();
  res.json(reviews);
}));

// Get single review by MongoDB ObjectId
router.get('/:id', [
  param('id').isMongoId().withMessage('Invalid review ID')
], handleValidationErrors, asyncHandler(async (req, res) => {
  const db = req.db;
  const review = await db.collection('reviews').findOne({ 
    _id: new ObjectId(req.params.id) 
  });
  
  if (!review) {
    return res.status(404).json({ error: 'Review not found' });
  }
  
  res.json(review);
}));

// Get single review by custom ID
router.get('/id/:reviewId', [
  param('reviewId').notEmpty().withMessage('Review ID is required')
], handleValidationErrors, asyncHandler(async (req, res) => {
  const db = req.db;
  const review = await db.collection('reviews').findOne({ 
    id: req.params.reviewId 
  });
  
  if (!review) {
    return res.status(404).json({ error: 'Review not found' });
  }
  
  res.json(review);
}));

// Get reviews by product
router.get('/product/:productId', [
  param('productId').notEmpty().withMessage('Product ID is required')
], handleValidationErrors, asyncHandler(async (req, res) => {
  const db = req.db;
  const reviews = await db.collection('reviews').find({ 
    product_id: req.params.productId 
  }).toArray();
  
  res.json(reviews);
}));

// Get reviews by user
router.get('/user/:userId', [
  param('userId').notEmpty().withMessage('User ID is required')
], handleValidationErrors, asyncHandler(async (req, res) => {
  const db = req.db;
  const reviews = await db.collection('reviews').find({ 
    user_id: req.params.userId 
  }).toArray();
  
  res.json(reviews);
}));

// Update review by MongoDB ObjectId
router.put('/:id', [
  param('id').isMongoId().withMessage('Invalid review ID'),
  body('rating').optional().isInt({ min: 1, max: 5 }).withMessage('Rating must be between 1 and 5'),
  body('comment').optional().notEmpty().withMessage('Comment cannot be empty')
], handleValidationErrors, asyncHandler(async (req, res) => {
  const db = req.db;
  const updateData = {
    ...req.body,
    date: new Date() // Update the date when modified
  };
  
  const result = await db.collection('reviews').updateOne(
    { _id: new ObjectId(req.params.id) },
    { $set: updateData }
  );
  
  if (result.matchedCount === 0) {
    return res.status(404).json({ error: 'Review not found' });
  }
  
  res.json({ message: 'Review updated successfully' });
}));

// Update review by custom ID
router.put('/id/:reviewId', [
  param('reviewId').notEmpty().withMessage('Review ID is required'),
  body('rating').optional().isInt({ min: 1, max: 5 }).withMessage('Rating must be between 1 and 5'),
  body('comment').optional().notEmpty().withMessage('Comment cannot be empty')
], handleValidationErrors, asyncHandler(async (req, res) => {
  const db = req.db;
  const updateData = {
    ...req.body,
    date: new Date() // Update the date when modified
  };
  
  const result = await db.collection('reviews').updateOne(
    { id: req.params.reviewId },
    { $set: updateData }
  );
  
  if (result.matchedCount === 0) {
    return res.status(404).json({ error: 'Review not found' });
  }
  
  res.json({ message: 'Review updated successfully' });
}));

// Delete review by MongoDB ObjectId
router.delete('/:id', [
  param('id').isMongoId().withMessage('Invalid review ID')
], handleValidationErrors, asyncHandler(async (req, res) => {
  const db = req.db;
  const result = await db.collection('reviews').deleteOne({ 
    _id: new ObjectId(req.params.id) 
  });
  
  if (result.deletedCount === 0) {
    return res.status(404).json({ error: 'Review not found' });
  }
  
  res.json({ message: 'Review deleted successfully' });
}));

// Delete review by custom ID
router.delete('/id/:reviewId', [
  param('reviewId').notEmpty().withMessage('Review ID is required')
], handleValidationErrors, asyncHandler(async (req, res) => {
  const db = req.db;
  const result = await db.collection('reviews').deleteOne({ 
    id: req.params.reviewId 
  });
  
  if (result.deletedCount === 0) {
    return res.status(404).json({ error: 'Review not found' });
  }
  
  res.json({ message: 'Review deleted successfully' });
}));

module.exports = router;