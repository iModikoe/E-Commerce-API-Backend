const express = require('express');
const { ObjectId } = require('mongodb');
const { body, validationResult, param } = require('express-validator');

const router = express.Router();

// Middleware for validation errors
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ 
      error: 'Validation failed', 
      details: errors.array() 
    });
  }
  next();
};

// Async error handler
const asyncHandler = (fn) => (req, res, next) => {
  Promise.resolve(fn(req, res, next)).catch(next);
};

// Create Refund
router.post('/', [
  body('order_id').notEmpty().withMessage('Order ID is required'),
  body('user_id').notEmpty().withMessage('User ID is required'),
  body('product_id').notEmpty().withMessage('Product ID is required'),
  body('refund_amount').isNumeric().withMessage('Refund amount must be a number'),
  body('refund_status').notEmpty().withMessage('Refund status is required'),
  body('refund_reason').notEmpty().withMessage('Refund reason is required'),
  body('request_date').isISO8601().toDate().withMessage('Request date must be a valid ISO date'),
  body('processed_date').optional().isISO8601().toDate().withMessage('Processed date must be a valid ISO date'),
  body('processed_by').optional().notEmpty().withMessage('Processed by cannot be empty'),
  body('transaction_id').notEmpty().withMessage('Transaction ID is required'),
  body('notes').optional().isString()
], handleValidationErrors, asyncHandler(async (req, res) => {
  const db = req.db;
  const refundData = {
    ...req.body,
    createdAt: new Date(),
    updatedAt: new Date()
  };

  const result = await db.collection('refunds').insertOne(refundData);
  res.status(201).json({ 
    message: 'Refund created successfully',
    refundId: result.insertedId 
  });
}));

// Get all refunds
router.get('/', asyncHandler(async (req, res) => {
  const db = req.db;
  const refunds = await db.collection('refunds').find({}).toArray();
  res.json(refunds);
}));

// Update refund
router.put('/:id', [
  param('id').isMongoId().withMessage('Invalid refund ID'),
  body('refund_amount').optional().isNumeric().withMessage('Refund amount must be a number'),
  body('refund_status').optional().notEmpty().withMessage('Refund status cannot be empty'),
  body('refund_reason').optional().notEmpty().withMessage('Refund reason cannot be empty'),
  body('processed_date').optional().isISO8601().toDate().withMessage('Processed date must be a valid ISO date'),
  body('processed_by').optional().notEmpty().withMessage('Processed by cannot be empty'),
  body('notes').optional().isString()
], handleValidationErrors, asyncHandler(async (req, res) => {
  const db = req.db;
  const updateData = {
    ...req.body,
    updatedAt: new Date()
  };

  const result = await db.collection('refunds').updateOne(
    { _id: new ObjectId(req.params.id) },
    { $set: updateData }
  );

  if (result.matchedCount === 0) {
    return res.status(404).json({ error: 'Refund not found' });
  }

  res.json({ message: 'Refund updated successfully' });
}));

// Delete refund
router.delete('/:id', [
  param('id').isMongoId().withMessage('Invalid refund ID')
], handleValidationErrors, asyncHandler(async (req, res) => {
  const db = req.db;
  const result = await db.collection('refunds').deleteOne({ 
    _id: new ObjectId(req.params.id) 
  });

  if (result.deletedCount === 0) {
    return res.status(404).json({ error: 'Refund not found' });
  }

  res.json({ message: 'Refund deleted successfully' });
}));

module.exports = router;