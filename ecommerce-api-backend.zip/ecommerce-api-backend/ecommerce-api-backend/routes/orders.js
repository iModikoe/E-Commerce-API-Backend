const express = require('express');
const { ObjectId } = require('mongodb');
const { body, validationResult, param } = require('express-validator');

const router = express.Router();

// Middleware for validation errors
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ 
      error: 'Validation failed', 
      details: errors.array() 
    });
  }
  next();
};

// Async error handler
const asyncHandler = (fn) => (req, res, next) => {
  Promise.resolve(fn(req, res, next)).catch(next);
};

// Create order
router.post('/', [
  body('user_id').notEmpty().withMessage('User ID is required'),
  body('product_id').notEmpty().withMessage('Product ID is required'),
  body('quantity').isInt({ min: 1 }).withMessage('Quantity must be at least 1'),
  body('price').isNumeric().withMessage('Price must be a number'),
  body('total_price').isNumeric().withMessage('Total price must be a number')
], handleValidationErrors, asyncHandler(async (req, res) => {
  const db = req.db;
  
  // Verify user exists
  const user = await db.collection('users').findOne({ 
    id: req.body.user_id 
  });
  
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  
  // Verify product exists and has sufficient stock
  const product = await db.collection('products').findOne({ 
    id: req.body.product_id 
  });
  
  if (!product) {
    return res.status(404).json({ 
      error: `Product ${req.body.product_id} not found` 
    });
  }
  
  if (product.stock < req.body.quantity) {
    return res.status(400).json({ 
      error: `Insufficient stock for product ${product.name}. Available: ${product.stock}, Requested: ${req.body.quantity}` 
    });
  }
  
  // Validate price calculation
  const expectedTotal = req.body.price * req.body.quantity;
  if (Math.abs(expectedTotal - req.body.total_price) > 0.01) {
    return res.status(400).json({ 
      error: 'Total price does not match price × quantity' 
    });
  }
  
  // Generate order ID
  const orderCount = await db.collection('orders').countDocuments();
  const orderId = `order_${String(orderCount + 1).padStart(3, '0')}`;
  
  const orderData = {
    id: orderId,
    user_id: req.body.user_id,
    product_id: req.body.product_id,
    quantity: req.body.quantity,
    price: req.body.price,
    total_price: req.body.total_price,
    order_date: new Date(),
    status: req.body.status || 'pending'
  };
  
  const result = await db.collection('orders').insertOne(orderData);
  
  // Update product stock
  await db.collection('products').updateOne(
    { id: req.body.product_id },
    { $inc: { stock: -req.body.quantity } }
  );
  
  res.status(201).json({ 
    message: 'Order created successfully',
    orderId: result.insertedId,
    order: orderData
  });
}));

// Get orders
router.get('/', asyncHandler(async (req, res) => {
  const db = req.db;
  const filter = {};
  if (req.query.user_id) filter.user_id = req.query.user_id;
  if (req.query.product_id) filter.product_id = req.query.product_id;
  if (req.query.status) filter.status = req.query.status;
  
  // Add date range filtering
  if (req.query.start_date || req.query.end_date) {
    filter.order_date = {};
    if (req.query.start_date) {
      filter.order_date.$gte = new Date(req.query.start_date);
    }
    if (req.query.end_date) {
      filter.order_date.$lte = new Date(req.query.end_date);
    }
  }
  
  const orders = await db.collection('orders').find(filter).toArray();
  res.json(orders);
}));

// Get single order by MongoDB ObjectId
router.get('/:id', [
  param('id').isMongoId().withMessage('Invalid order ID')
], handleValidationErrors, asyncHandler(async (req, res) => {
  const db = req.db;
  const order = await db.collection('orders').findOne({ 
    _id: new ObjectId(req.params.id) 
  });
  
  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }
  
  res.json(order);
}));

// Get single order by custom ID
router.get('/id/:orderId', [
  param('orderId').notEmpty().withMessage('Order ID is required')
], handleValidationErrors, asyncHandler(async (req, res) => {
  const db = req.db;
  const order = await db.collection('orders').findOne({ 
    id: req.params.orderId 
  });
  
  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }
  
  res.json(order);
}));

// Get orders by user
router.get('/user/:userId', [
  param('userId').notEmpty().withMessage('User ID is required')
], handleValidationErrors, asyncHandler(async (req, res) => {
  const db = req.db;
  const orders = await db.collection('orders').find({ 
    user_id: req.params.userId 
  }).toArray();
  
  res.json(orders);
}));

// Get orders by product
router.get('/product/:productId', [
  param('productId').notEmpty().withMessage('Product ID is required')
], handleValidationErrors, asyncHandler(async (req, res) => {
  const db = req.db;
  const orders = await db.collection('orders').find({ 
    product_id: req.params.productId 
  }).toArray();
  
  res.json(orders);
}));

// Update order by MongoDB ObjectId
router.put('/:id', [
  param('id').isMongoId().withMessage('Invalid order ID'),
  body('quantity').optional().isInt({ min: 1 }).withMessage('Quantity must be at least 1'),
  body('price').optional().isNumeric().withMessage('Price must be a number'),
  body('total_price').optional().isNumeric().withMessage('Total price must be a number'),
  body('status').optional().isIn(['pending', 'processing', 'shipped', 'delivered', 'cancelled'])
    .withMessage('Invalid status')
], handleValidationErrors, asyncHandler(async (req, res) => {
  const db = req.db;
  const updateData = {
    ...req.body,
    order_date: new Date() // Update order date when modified
  };
  
  // Validate price calculation if both price and quantity are provided
  if (req.body.price && req.body.quantity && req.body.total_price) {
    const expectedTotal = req.body.price * req.body.quantity;
    if (Math.abs(expectedTotal - req.body.total_price) > 0.01) {
      return res.status(400).json({ 
        error: 'Total price does not match price × quantity' 
      });
    }
  }
  
  const result = await db.collection('orders').updateOne(
    { _id: new ObjectId(req.params.id) },
    { $set: updateData }
  );
  
  if (result.matchedCount === 0) {
    return res.status(404).json({ error: 'Order not found' });
  }
  
  res.json({ message: 'Order updated successfully' });
}));

// Update order by custom ID
router.put('/id/:orderId', [
  param('orderId').notEmpty().withMessage('Order ID is required'),
  body('quantity').optional().isInt({ min: 1 }).withMessage('Quantity must be at least 1'),
  body('price').optional().isNumeric().withMessage('Price must be a number'),
  body('total_price').optional().isNumeric().withMessage('Total price must be a number'),
  body('status').optional().isIn(['pending', 'processing', 'shipped', 'delivered', 'cancelled'])
    .withMessage('Invalid status')
], handleValidationErrors, asyncHandler(async (req, res) => {
  const db = req.db;
  const updateData = {
    ...req.body,
    order_date: new Date() // Update order date when modified
  };
  
  // Validate price calculation if both price and quantity are provided
  if (req.body.price && req.body.quantity && req.body.total_price) {
    const expectedTotal = req.body.price * req.body.quantity;
    if (Math.abs(expectedTotal - req.body.total_price) > 0.01) {
      return res.status(400).json({ 
        error: 'Total price does not match price × quantity' 
      });
    }
  }
  
  const result = await db.collection('orders').updateOne(
    { id: req.params.orderId },
    { $set: updateData }
  );
  
  if (result.matchedCount === 0) {
    return res.status(404).json({ error: 'Order not found' });
  }
  
  res.json({ message: 'Order updated successfully' });
}));

// Update order status by MongoDB ObjectId
router.patch('/:id/status', [
  param('id').isMongoId().withMessage('Invalid order ID'),
  body('status').isIn(['pending', 'processing', 'shipped', 'delivered', 'cancelled'])
    .withMessage('Invalid status')
], handleValidationErrors, asyncHandler(async (req, res) => {
  const db = req.db;
  const result = await db.collection('orders').updateOne(
    { _id: new ObjectId(req.params.id) },
    { 
      $set: { 
        status: req.body.status,
        order_date: new Date()
      }
    }
  );
  
  if (result.matchedCount === 0) {
    return res.status(404).json({ error: 'Order not found' });
  }
  
  res.json({ message: 'Order status updated successfully' });
}));

// Update order status by custom ID
router.patch('/id/:orderId/status', [
  param('orderId').notEmpty().withMessage('Order ID is required'),
  body('status').isIn(['pending', 'processing', 'shipped', 'delivered', 'cancelled'])
    .withMessage('Invalid status')
], handleValidationErrors, asyncHandler(async (req, res) => {
  const db = req.db;
  const result = await db.collection('orders').updateOne(
    { id: req.params.orderId },
    { 
      $set: { 
        status: req.body.status,
        order_date: new Date()
      }
    }
  );
  
  if (result.matchedCount === 0) {
    return res.status(404).json({ error: 'Order not found' });
  }
  
  res.json({ message: 'Order status updated successfully' });
}));

// Delete order by MongoDB ObjectId
router.delete('/:id', [
  param('id').isMongoId().withMessage('Invalid order ID')
], handleValidationErrors, asyncHandler(async (req, res) => {
  const db = req.db;
  // Get order details before deletion to restore stock
  const order = await db.collection('orders').findOne({ 
    _id: new ObjectId(req.params.id) 
  });
  
  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }
  
  const result = await db.collection('orders').deleteOne({ 
    _id: new ObjectId(req.params.id) 
  });
  
  // Restore product stock
  await db.collection('products').updateOne(
    { id: order.product_id },
    { $inc: { stock: order.quantity } }
  );
  
  res.json({ message: 'Order deleted successfully' });
}));

// Delete order by custom ID
router.delete('/id/:orderId', [
  param('orderId').notEmpty().withMessage('Order ID is required')
], handleValidationErrors, asyncHandler(async (req, res) => {
  const db = req.db;
  // Get order details before deletion to restore stock
  const order = await db.collection('orders').findOne({ 
    id: req.params.orderId 
  });
  
  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }
  
  const result = await db.collection('orders').deleteOne({ 
    id: req.params.orderId 
  });
  
  // Restore product stock
  await db.collection('products').updateOne(
    { id: order.product_id },
    { $inc: { stock: order.quantity } }
  );
  
  res.json({ message: 'Order deleted successfully' });
}));

module.exports = router;