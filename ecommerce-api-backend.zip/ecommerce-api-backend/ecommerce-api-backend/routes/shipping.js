const express = require('express');
const { ObjectId } = require('mongodb');
const { body, validationResult, param } = require('express-validator');

const router = express.Router();

// Middleware to check database connection
const checkDB = (req, res, next) => {
  if (!req.db) {
    return res.status(503).json({ error: 'Database connection not available' });
  }
  next();
};

// Error handling middleware
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ 
      error: 'Validation failed', 
      details: errors.array() 
    });
  }
  next();
};

// Async error handler
const asyncHandler = (fn) => (req, res, next) => {
  Promise.resolve(fn(req, res, next)).catch(next);
};

// Create Shipping
router.post('/', [
  body('order_id').notEmpty().withMessage('Order ID is required'),
  body('user_id').notEmpty().withMessage('User ID is required'),
  body('courier').notEmpty().withMessage('Courier is required'),
  body('tracking_number').notEmpty().withMessage('Tracking number is required'),
  body('shipping_status').notEmpty().withMessage('Shipping status is required'),
  body('dispatched_date').isISO8601().toDate().withMessage('Dispatched date must be a valid ISO date'),
  body('estimated_delivery').isISO8601().toDate().withMessage('Estimated delivery must be a valid ISO date'),
  body('actual_delivery').optional().isISO8601().toDate().withMessage('Actual delivery must be a valid ISO date'),
  body('delivery_address').isObject().withMessage('Delivery address must be an object')
], checkDB, handleValidationErrors, asyncHandler(async (req, res) => {
  const shippingData = {
    ...req.body,
    last_updated: new Date(),
    createdAt: new Date()
  };

  const result = await req.db.collection('shippings').insertOne(shippingData);
  res.status(201).json({ 
    message: 'Shipping record created successfully',
    shippingId: result.insertedId 
  });
}));

// Get all shippings
router.get('/', checkDB, asyncHandler(async (req, res) => {
  const shippings = await req.db.collection('shippings').find({}).toArray();
  res.json(shippings);
}));

// Update Shipping
router.put('/:id', [
  param('id').isMongoId().withMessage('Invalid shipping ID'),
  body('shipping_status').optional().notEmpty().withMessage('Shipping status cannot be empty'),
  body('tracking_number').optional().notEmpty().withMessage('Tracking number cannot be empty'),
  body('actual_delivery').optional().isISO8601().toDate().withMessage('Actual delivery must be a valid ISO date'),
  body('delivery_address').optional().isObject().withMessage('Delivery address must be an object')
], checkDB, handleValidationErrors, asyncHandler(async (req, res) => {
  const updateData = {
    ...req.body,
    last_updated: new Date()
  };

  const result = await req.db.collection('shippings').updateOne(
    { _id: new ObjectId(req.params.id) },
    { $set: updateData }
  );

  if (result.matchedCount === 0) {
    return res.status(404).json({ error: 'Shipping record not found' });
  }

  res.json({ message: 'Shipping record updated successfully' });
}));

// Delete Shipping
router.delete('/:id', [
  param('id').isMongoId().withMessage('Invalid shipping ID')
], checkDB, handleValidationErrors, asyncHandler(async (req, res) => {
  const result = await req.db.collection('shippings').deleteOne({ 
    _id: new ObjectId(req.params.id) 
  });

  if (result.deletedCount === 0) {
    return res.status(404).json({ error: 'Shipping record not found' });
  }

  res.json({ message: 'Shipping record deleted successfully' });
}));

module.exports = router;