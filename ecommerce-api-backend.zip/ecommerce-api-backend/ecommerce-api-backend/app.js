const express = require('express');
const { MongoClient } = require('mongodb');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
require('dotenv').config();


// Import routes
const productRoutes = require('./routes/products');
const userRoutes = require('./routes/users');
const orderRoutes = require('./routes/orders');
const reviewRoutes = require('./routes/reviews');
const refundRoutes = require('./routes/refunds');
const shippingRoutes = require('./routes/shipping');
const paymentRoutes = require('./routes/payments');
const discountRoutes = require('./routes/discounts');

const app = express();

// Security middleware
app.use(helmet());
app.use(cors({
  origin: process.env.ALLOWED_ORIGINS?.split(',') || ['http://localhost:8000'],
  credentials: true
}));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: 'Too many requests from this IP, please try again later.'
});
app.use(limiter);

app.use(express.json({ limit: '10mb' }));

// MongoDB connection
const dbURL = process.env.DATABASE_CONN_URL;
const port = process.env.PORT || 8000;
const dbName = process.env.DB_NAME || 'ecommerce';

if (!dbURL) {
  console.error('DATABASE_CONN_URL environment variable is required');
  process.exit(1);
}

const client = new MongoClient(dbURL, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

let db;

// Database connection with retry logic
async function connectDB() {
  try {
    await client.connect();
    db = client.db(dbName);
    console.log(`Connected to MongoDB database: ${dbName}`);
    return db;
  } catch (error) {
    console.error('Failed to connect to MongoDB:', error);
    setTimeout(connectDB, 5000); // Retry after 5 seconds
    return null;
  }
}

connectDB();

// Middleware to check database connection
const checkDB = (req, res, next) => {
  if (!db) {
    return res.status(503).json({ error: 'Database connection not available' });
  }
  next();
};

// Async error handler
const asyncHandler = (fn) => (req, res, next) => {
  Promise.resolve(fn(req, res, next)).catch(next);
};

// Make asyncHandler available to routes
app.locals.asyncHandler = asyncHandler;

// Routes
app.use('/products', checkDB, productRoutes);
app.use('/users', checkDB, userRoutes);
app.use('/orders', checkDB, orderRoutes);
app.use('/reviews', checkDB, reviewRoutes);
app.use('/refunds', checkDB, refundRoutes);
app.use('/shippings', checkDB, shippingRoutes);
app.use('/payments', checkDB, paymentRoutes);
app.use('/discounts', checkDB, discountRoutes);

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    timestamp: new Date().toISOString(),
    database: db ? 'Connected' : 'Disconnected'
  });
});

// Global error handler
app.use((error, req, res, next) => {
  console.error('Error:', error);
  
  if (error.name === 'ValidationError') {
    return res.status(400).json({ error: 'Validation error', details: error.message });
  }
  
  if (error.name === 'CastError') {
    return res.status(400).json({ error: 'Invalid ID format' });
  }
  
  res.status(500).json({ 
    error: 'Internal server error',
    message: process.env.NODE_ENV === 'development' ? error.message : 'Something went wrong'
  });
});

// Shutdown
process.on('SIGINT', async () => {
  console.log('Shutting down...');
  if (client) {
    await client.close();
    console.log('MongoDB connection closed');
  }
  process.exit(0);
});

// Start server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
  console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
});