const mongoose = require('mongoose')


const reviewSchema = new mongoose.Schema ({
    productId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'product',
        required: true,
        index: true,
    },
    userId:{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'user',
        required: true,
        index: true,
    },
    rating: {
        type: Number,
        required: true,
        min: [1, 'Rating must be at least 1'],
        max: [5, 'Rating cannot exceed 5'],
        validate: {
            validator: function(value) {
                return Number.isInteger(value) || (value % 0.5 === 0);
            },
            message: 'Rating must be a whole number or half number (e.g., 1, 1.5, 2, etc.)'
        }
    },
    comment: {
        type: String,
        required: true,
        trim: true,
        maxlength: [1000, 'Review comment cannot exceed 1000 characters'],
        minlength: [10, 'Review comment must be at least 10 characters']
    },
    timestamps: true, // Automatically adds createdAt and updatedAt
    toJSON: { virtuals: true },
    toObject: { virtuals: true }
});

// Static method to find reviews by product with pagination
reviewSchema.statics.findByProduct = function(productId, page = 1, limit = 10, sortBy = 'createdAt') {
    const skip = (page - 1) * limit;
    return this.find({ productId, status: 'approved' })
        .populate('userId', 'name avatar')
        .sort({ [sortBy]: -1 })
        .skip(skip)
        .limit(limit);
};

const Review = mongoose.model('user', reviewSchema);

module.exports = Review;